const path = require("path");
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");

const db = require("./lib/db");
const { calcEGFR, gfrStage } = require("./public/js/gfr.js");

const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || "pd-tracker-" + Math.random().toString(36).slice(2);

const app = express();
app.use(express.json());
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 12 }, // 12h
  })
);

// ---------- Auth helpers ----------
function requireAuth(req, res, next) {
  if (req.session && req.session.loggedIn) return next();
  return res.status(401).json({ error: "not_authenticated" });
}

app.get("/api/session", (req, res) => {
  const settings = db.getSettings();
  res.json({
    needsSetup: !settings.passwordHash,
    loggedIn: !!(req.session && req.session.loggedIn),
  });
});

app.post("/api/setup", async (req, res) => {
  const settings = db.getSettings();
  if (settings.passwordHash) {
    return res.status(400).json({ error: "already_set_up" });
  }
  const { password } = req.body || {};
  if (!password || String(password).length < 4) {
    return res.status(400).json({ error: "password_too_short" });
  }
  const hash = await bcrypt.hash(String(password), 10);
  await db.setPasswordHash(hash);
  req.session.loggedIn = true;
  res.json({ ok: true });
});

app.post("/api/login", async (req, res) => {
  const settings = db.getSettings();
  if (!settings.passwordHash) return res.status(400).json({ error: "needs_setup" });
  const { password } = req.body || {};
  const ok = password && (await bcrypt.compare(String(password), settings.passwordHash));
  if (!ok) return res.status(401).json({ error: "invalid_password" });
  req.session.loggedIn = true;
  res.json({ ok: true });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.post("/api/change-password", requireAuth, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const settings = db.getSettings();
  const ok = currentPassword && (await bcrypt.compare(String(currentPassword), settings.passwordHash));
  if (!ok) return res.status(401).json({ error: "invalid_password" });
  if (!newPassword || String(newPassword).length < 4) {
    return res.status(400).json({ error: "password_too_short" });
  }
  const hash = await bcrypt.hash(String(newPassword), 10);
  await db.setPasswordHash(hash);
  res.json({ ok: true });
});

// ---------- Patient helpers ----------
function computeDerived(patient) {
  const out = Object.assign({}, patient);
  if (patient.hasLabs && patient.creatinine && patient.age && patient.gender) {
    out.egfr = calcEGFR(patient.creatinine, patient.age, patient.gender);
    out.stage = gfrStage(out.egfr);
  } else {
    out.egfr = null;
    out.stage = null;
  }
  // BSA - Mosteller formula: sqrt((height_cm * weight_kg) / 3600)
  const w = patient.vitals && patient.vitals.weight;
  const h = patient.vitals && patient.vitals.height;
  if (w && h) {
    out.bsa = Math.round(Math.sqrt((h * w) / 3600) * 100) / 100;
  } else {
    out.bsa = null;
  }
  return out;
}

function boolOrNull(v) {
  return v === true ? true : v === false ? false : null;
}
function numOrNull(v) {
  return v !== undefined && v !== null && v !== "" && !isNaN(Number(v)) ? Number(v) : null;
}
function strOrNull(v, max) {
  return v ? String(v).slice(0, max || 500) : null;
}

function sanitizePatientInput(body) {
  const criteria = body.criteria || {};
  const allowedCriteriaKeys = [
    "chronicConstipation",
    "chronicCough",
    "smoker",
    "hasCaregiver",
    "abdominalSurgery",
    "hygiene",
  ];
  const cleanCriteria = {};
  allowedCriteriaKeys.forEach((k) => {
    cleanCriteria[k] = boolOrNull(criteria[k]);
  });
  let otherCriterion = null;
  if (body.otherCriterion && body.otherCriterion.label) {
    otherCriterion = {
      label: String(body.otherCriterion.label).slice(0, 120),
      value: body.otherCriterion.value === true,
    };
  }

  const vitals = body.vitals || {};
  const dialysis = body.dialysis || {};
  const extraLabs = body.extraLabs || {};
  const comorbid = body.comorbid || {};
  const smokingDetail = comorbid.smokingDetail || {};
  const hernia = body.hernia || {};
  const fluid = body.fluid || {};
  const teamAssessment = body.teamAssessment || {};
  const medications = Array.isArray(body.medications) ? body.medications : [];

  return {
    name: String(body.name || "").slice(0, 200),
    phone: String(body.phone || "").slice(0, 40),
    gender: body.gender === "male" || body.gender === "female" ? body.gender : null,
    age: body.age ? Number(body.age) : null,
    dob: strOrNull(body.dob, 20),
    address: strOrNull(body.address, 300),
    referringDoctor: strOrNull(body.referringDoctor, 150),
    visitDate: body.visitDate || null,
    hasFile: !!body.hasFile,
    fileNumber: strOrNull(body.fileNumber, 60),

    vitals: {
      bp: strOrNull(vitals.bp, 20),
      pr: numOrNull(vitals.pr),
      weight: numOrNull(vitals.weight),
      height: numOrNull(vitals.height),
    },

    dialysis: {
      causeOfEsrd: strOrNull(dialysis.causeOfEsrd, 60),
      causeOfEsrdOther: strOrNull(dialysis.causeOfEsrdOther, 150),
      onsetDate: dialysis.onsetDate || null,
      accessType: ["avf", "temp_catheter", "perm_catheter", "none"].includes(dialysis.accessType)
        ? dialysis.accessType
        : null,
      accessSide: ["left", "right"].includes(dialysis.accessSide) ? dialysis.accessSide : null,
      accessFailure: boolOrNull(dialysis.accessFailure),
    },

    hasLabs: !!body.hasLabs,
    labsDueDate: body.labsDueDate || null,
    urea: numOrNull(body.urea),
    creatinine: numOrNull(body.creatinine),
    labDate: body.labDate || null,

    extraLabs: {
      hgb: numOrNull(extraLabs.hgb),
      albumin: numOrNull(extraLabs.albumin),
      k: numOrNull(extraLabs.k),
      ca: numOrNull(extraLabs.ca),
      phos: numOrNull(extraLabs.phos),
      glucose: numOrNull(extraLabs.glucose),
      hbsag: ["negative", "positive"].includes(extraLabs.hbsag) ? extraLabs.hbsag : null,
      hcv: ["negative", "positive"].includes(extraLabs.hcv) ? extraLabs.hcv : null,
      hiv: ["negative", "positive"].includes(extraLabs.hiv) ? extraLabs.hiv : null,
      bloodGroup: strOrNull(extraLabs.bloodGroup, 10),
    },

    comorbid: {
      diabetes: ["none", "insulin", "oral"].includes(comorbid.diabetes) ? comorbid.diabetes : "none",
      diabetesControl: ["good", "poor"].includes(comorbid.diabetesControl) ? comorbid.diabetesControl : null,
      hypertension: boolOrNull(comorbid.hypertension),
      htnMeds: strOrNull(comorbid.htnMeds, 200),
      cardiac: boolOrNull(comorbid.cardiac),
      cardiacDx: strOrNull(comorbid.cardiacDx, 200),
      ef: numOrNull(comorbid.ef),
      chronicRespiratory: boolOrNull(comorbid.chronicRespiratory),
      smokingDetail: {
        cigarettesPerDay: numOrNull(smokingDetail.cigarettesPerDay),
        yearsSmoking: numOrNull(smokingDetail.yearsSmoking),
        quitDate: smokingDetail.quitDate || null,
      },
    },

    abdominalSurgeryDetail: strOrNull(body.abdominalSurgeryDetail, 300),
    hernia: {
      present: boolOrNull(hernia.present),
      type: ["umbilical", "paraumbilical", "inguinal"].includes(hernia.type) ? hernia.type : null,
    },
    fluid: {
      intakeDescription: strOrNull(fluid.intakeDescription, 150),
      fastFoodFrequency: ["rarely", "sometimes", "often"].includes(fluid.fastFoodFrequency)
        ? fluid.fastFoodFrequency
        : null,
      priorFluidOverloadAdmission: boolOrNull(fluid.priorFluidOverloadAdmission),
      admissionsLast6Months: numOrNull(fluid.admissionsLast6Months),
    },

    criteria: cleanCriteria,
    otherCriterion: otherCriterion,

    medications: medications.slice(0, 30).map((m) => ({
      name: strOrNull(m.name, 120) || "",
      dose: strOrNull(m.dose, 60) || "",
      route: strOrNull(m.route, 40) || "",
      frequency: strOrNull(m.frequency, 60) || "",
    })).filter((m) => m.name),

    teamAssessment: {
      surgeonNotes: strOrNull(teamAssessment.surgeonNotes, 2000),
      nephrologistNotes: strOrNull(teamAssessment.nephrologistNotes, 2000),
      acceptedByPdCoordinator: boolOrNull(teamAssessment.acceptedByPdCoordinator),
      acceptedBySurgeon: boolOrNull(teamAssessment.acceptedBySurgeon),
      acceptedByNephrology: boolOrNull(teamAssessment.acceptedByNephrology),
    },

    fitForPd: ["fit", "not_fit", "pending"].includes(body.fitForPd) ? body.fitForPd : "pending",
    plan: ["follow_up", "pd_cath_insertion", "pre_hd_clinic"].includes(body.plan) ? body.plan : null,
    followUpDate: body.followUpDate || null,
    notes: String(body.notes || "").slice(0, 2000),
  };
}

// ---------- Patient routes ----------
app.get("/api/patients", requireAuth, (req, res) => {
  const sort = req.query.sort || "date";
  const filter = req.query.filter || "all";
  let patients = db.listPatients().map(computeDerived);

  if (filter === "fit") {
    patients = patients.filter((p) => p.fitForPd === "fit");
  } else if (filter === "pending") {
    patients = patients.filter((p) => p.fitForPd === "pending");
  } else if (filter === "pre_hd") {
    patients = patients.filter((p) => p.plan === "pre_hd_clinic");
  }

  function byNumberDesc(field) {
    return (a, b) => {
      const av = a[field] === null || a[field] === undefined ? -Infinity : a[field];
      const bv = b[field] === null || b[field] === undefined ? -Infinity : b[field];
      return bv - av;
    };
  }

  if (sort === "urea") {
    patients = patients.slice().sort(byNumberDesc("urea"));
  } else if (sort === "creatinine") {
    patients = patients.slice().sort(byNumberDesc("creatinine"));
  } else {
    // "date" (default): sort by visit date, newest first; fall back to createdAt when visitDate is missing
    patients = patients.slice().sort((a, b) => {
      const ad = new Date(a.visitDate || a.createdAt);
      const bd = new Date(b.visitDate || b.createdAt);
      return bd - ad;
    });
  }
  res.json({ patients });
});

app.get("/api/patients/:id", requireAuth, (req, res) => {
  const patient = db.getPatient(Number(req.params.id));
  if (!patient) return res.status(404).json({ error: "not_found" });
  res.json({ patient: computeDerived(patient) });
});

app.post("/api/patients", requireAuth, async (req, res) => {
  const clean = sanitizePatientInput(req.body || {});
  if (!clean.name) return res.status(400).json({ error: "name_required" });
  const record = await db.createPatient(clean);
  res.json({ patient: computeDerived(record) });
});

app.put("/api/patients/:id", requireAuth, async (req, res) => {
  const clean = sanitizePatientInput(req.body || {});
  if (!clean.name) return res.status(400).json({ error: "name_required" });
  const record = await db.updatePatient(Number(req.params.id), clean);
  if (!record) return res.status(404).json({ error: "not_found" });
  res.json({ patient: computeDerived(record) });
});

app.delete("/api/patients/:id", requireAuth, async (req, res) => {
  const ok = await db.deletePatient(Number(req.params.id));
  if (!ok) return res.status(404).json({ error: "not_found" });
  res.json({ ok: true });
});

app.get("/api/stats", requireAuth, (req, res) => {
  const patients = db.listPatients().map(computeDerived);
  const total = patients.length;
  const fit = patients.filter((p) => p.fitForPd === "fit").length;
  const notFit = patients.filter((p) => p.fitForPd === "not_fit").length;
  const pending = patients.filter((p) => p.fitForPd === "pending").length;
  const labsDue = patients.filter((p) => !p.hasLabs).length;
  const egfrValues = patients.filter((p) => typeof p.egfr === "number").map((p) => p.egfr);
  const avgEgfr = egfrValues.length
    ? Math.round((egfrValues.reduce((a, b) => a + b, 0) / egfrValues.length) * 10) / 10
    : null;
  const planCounts = {
    follow_up: patients.filter((p) => p.plan === "follow_up").length,
    pd_cath_insertion: patients.filter((p) => p.plan === "pd_cath_insertion").length,
    pre_hd_clinic: patients.filter((p) => p.plan === "pre_hd_clinic").length,
  };
  res.json({ total, fit, notFit, pending, labsDue, avgEgfr, planCounts });
});

// ---------- Static frontend ----------
app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`PD Education Tracker running at http://localhost:${PORT}`);
});
