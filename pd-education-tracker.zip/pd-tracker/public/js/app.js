(function () {
  "use strict";
  const t = window.I18N.t;

  /* ============ tiny helpers ============ */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }
  function todayIso() {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${m}-${day}`;
  }
  function fmtDate(iso) {
    if (!iso) return t("notSet");
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return iso;
      return d.toLocaleDateString(window.I18N.getLang() === "ar" ? "ar-EG" : "en-GB", {
        year: "numeric", month: "short", day: "2-digit",
      });
    } catch (e) { return iso; }
  }

  /* ============ referring doctor directory ============ */
  const REFERRING_DOCTORS = [
    { hospital: "KFSH", doctors: [
      { key: "kfsh_ahmad_alsalloom", label: "Dr. Ahmad Alsalloom" },
      { key: "kfsh_ibrahim_sabbhawi", label: "Ibrahim Sabbhawi" },
      { key: "kfsh_fahad_alharbi", label: "Fahad Alharbi" },
      { key: "kfsh_motaz", label: "Motaz" },
      { key: "kfsh_dina", label: "Dina" },
    ]},
    { hospital: "KSH", doctors: [
      { key: "ksh_saeed", label: "Dr. Saeed" },
      { key: "ksh_hisham", label: "Hisham" },
      { key: "ksh_heba", label: "Heba" },
    ]},
    { hospital: "BCH", doctors: [
      { key: "bch_rakan", label: "Rakan" },
      { key: "bch_maha", label: "Maha" },
      { key: "bch_abu_baker", label: "Abu Baker" },
      { key: "bch_bader_alharbi", label: "Bader Alharbi" },
      { key: "bch_abdulrahman", label: "Abdulrahman" },
    ]},
    { hospital: "Albukariah", doctors: [
      { key: "albukariah_rania", label: "Dr. Rania" },
    ]},
  ];
  function referringDoctorLabel(patient) {
    const key = patient.referringDoctor;
    if (!key) return null;
    if (key === "other") return patient.referringDoctorOther || null;
    for (const g of REFERRING_DOCTORS) {
      const doc = g.doctors.find((x) => x.key === key);
      if (doc) return `${doc.label} (${g.hospital})`;
    }
    return key; // legacy free-text value entered before this list existed
  }

  async function api(path, opts) {
    const res = await fetch(path, Object.assign({
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
    }, opts || {}));
    if (res.status === 401) {
      showAuth();
      throw new Error("not_authenticated");
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || "request_failed");
      err.data = data;
      throw err;
    }
    return data;
  }

  function toast(msg, isError) {
    const el = document.createElement("div");
    el.className = "toast" + (isError ? " error" : "");
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }

  /* ============ i18n application ============ */
  function applyStaticTranslations() {
    $all("[data-t]").forEach((el) => { el.textContent = t(el.getAttribute("data-t")); });
    $all("[data-t-placeholder]").forEach((el) => { el.placeholder = t(el.getAttribute("data-t-placeholder")); });
    $all("[data-t-label]").forEach((el) => { el.label = t(el.getAttribute("data-t-label")); });
  }
  function setLanguage(lang) {
    window.I18N.setLang(lang);
    document.documentElement.lang = lang;
    document.body.dir = lang === "ar" ? "rtl" : "ltr";
    applyStaticTranslations();
    $("#auth-lang-toggle").textContent = t("langToggle");
    $("#btn-lang-toggle").textContent = t("langToggle");
    // re-render whichever dynamic view is active
    if (state.view === "dashboard") renderDashboard();
    if (state.view === "form") renderWizard();
    if (state.view === "patient") renderPatientDetail(state.currentPatientId);
    if (state.view === "education") renderEducation();
    renderAuthTexts();
  }

  /* ============ app state ============ */
  const state = {
    view: "dashboard",
    needsSetup: false,
    patients: [],
    stats: null,
    sort: "date",
    filter: "all",
    search: "",
    currentPatientId: null,
    wizard: { step: 1, editingId: null, data: emptyPatient() },
  };

  function emptyPatient() {
    return {
      name: "", phone: "", gender: "", age: "", dob: "", address: "",
      patientSource: "", referringDoctor: "", referringDoctorOther: "",
      visitDate: todayIso(),
      hasFile: false, fileNumber: "",
      vitals: { bp: "", pr: "", weight: "", height: "" },

      dialysis: {
        causeOfEsrd: "", causeOfEsrdOther: "", onsetDate: "",
        accessType: "", accessSide: "", accessFailure: null,
      },

      hasLabs: false, labsDueDate: "", urea: "", creatinine: "", labDate: "",
      showExtraLabs: false,
      extraLabs: {
        hgb: "", albumin: "", k: "", ca: "", phos: "", glucose: "",
        hbsag: "", hcv: "", hiv: "", bloodGroup: "",
      },

      comorbid: {
        diabetes: "none", diabetesControl: "",
        hypertension: null, htnMeds: "",
        cardiac: null, cardiacDx: "", ef: "",
        chronicRespiratory: null,
        smokingDetail: { cigarettesPerDay: "", yearsSmoking: "", quitDate: "" },
      },

      criteria: {
        chronicConstipation: null, chronicCough: null, smoker: null,
        hasCaregiver: null, abdominalSurgery: null, hygiene: null,
      },
      otherCriterion: { label: "", value: null },
      abdominalSurgeryDetail: "",
      hernia: { present: null, type: "" },
      fluid: { intakeDescription: "", fastFoodFrequency: "", priorFluidOverloadAdmission: null, admissionsLast6Months: "" },

      medications: [],

      teamAssessment: {
        surgeonNotes: "", nephrologistNotes: "",
        pdCoordinatorName: "",
        acceptedByPdCoordinator: null, acceptedBySurgeon: null, acceptedByNephrology: null,
      },

      fitForPd: "pending", plan: "", followUpDate: "", notes: "",
      needsPdCathInsertion: null, pdCathInsertionArrangedDate: "",
      pdCatheterInserted: null, pdCatheterInsertedDate: "",
      dialysisStatus: "active", dialysisStartType: "", dialysisStartDate: "",
    };
  }

  /* ============ auth screen ============ */
  function renderAuthTexts() {
    if (state.needsSetup) {
      $("#auth-title").textContent = t("setupTitle");
      $("#auth-body").textContent = t("setupBody");
      $("#auth-submit").textContent = t("createPassword");
      $("#field-confirm").classList.remove("hidden");
    } else {
      $("#auth-title").textContent = t("loginTitle");
      $("#auth-body").textContent = t("loginBody");
      $("#auth-submit").textContent = t("signIn");
      $("#field-confirm").classList.add("hidden");
    }
  }

  function showAuth() {
    $("#view-auth").classList.remove("hidden");
    $("#app-shell").classList.add("hidden");
    renderAuthTexts();
  }
  function showApp() {
    $("#view-auth").classList.add("hidden");
    $("#app-shell").classList.remove("hidden");
  }

  $("#auth-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const pw = $("#input-password").value;
    $("#field-password").classList.remove("has-error");
    $("#field-confirm").classList.remove("has-error");
    if (state.needsSetup) {
      const confirm = $("#input-confirm").value;
      if (pw.length < 4) {
        $("#field-password").classList.add("has-error");
        $("#err-password").textContent = t("passwordTooShort");
        return;
      }
      if (pw !== confirm) {
        $("#field-confirm").classList.add("has-error");
        $("#err-confirm").textContent = t("passwordMismatch");
        return;
      }
      try {
        await api("/api/setup", { method: "POST", body: JSON.stringify({ password: pw }) });
        await bootApp();
      } catch (err) {
        toast(t("errorGeneric"), true);
      }
    } else {
      try {
        await api("/api/login", { method: "POST", body: JSON.stringify({ password: pw }) });
        await bootApp();
      } catch (err) {
        $("#field-password").classList.add("has-error");
        $("#err-password").textContent = t("invalidPassword");
      }
    }
  });

  $("#auth-lang-toggle").addEventListener("click", () => {
    setLanguage(window.I18N.getLang() === "ar" ? "en" : "ar");
  });
  $("#btn-lang-toggle").addEventListener("click", () => {
    setLanguage(window.I18N.getLang() === "ar" ? "en" : "ar");
  });
  $("#btn-logout").addEventListener("click", async () => {
    await api("/api/logout", { method: "POST" });
    location.reload();
  });

  /* ============ change password modal ============ */
  $("#btn-change-pw").addEventListener("click", () => {
    $("#pw-current").value = ""; $("#pw-new").value = ""; $("#pw-err").textContent = "";
    $("#modal-pw").classList.remove("hidden");
  });
  $("#pw-cancel").addEventListener("click", () => $("#modal-pw").classList.add("hidden"));
  $("#pw-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await api("/api/change-password", {
        method: "POST",
        body: JSON.stringify({ currentPassword: $("#pw-current").value, newPassword: $("#pw-new").value }),
      });
      $("#modal-pw").classList.add("hidden");
      toast(t("saved"));
    } catch (err) {
      $("#pw-err").textContent = err.data && err.data.error === "password_too_short" ? t("passwordTooShort") : t("invalidPassword");
    }
  });

  /* ============ nav tabs ============ */
  $all(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => navigateTo(btn.getAttribute("data-view")));
  });
  function navigateTo(view, opts) {
    state.view = view;
    $all(".tab-btn").forEach((b) => b.classList.toggle("active", b.getAttribute("data-view") === view));
    $all("#view-dashboard, #view-form, #view-patient, #view-education").forEach((s) => s.classList.add("hidden"));
    if (view === "dashboard") { $("#view-dashboard").classList.remove("hidden"); loadDashboard(); }
    if (view === "form") {
      $("#view-form").classList.remove("hidden");
      if (!(opts && opts.keep)) { state.wizard = { step: 1, editingId: null, data: emptyPatient() }; }
      renderWizard();
    }
    if (view === "patient") { $("#view-patient").classList.remove("hidden"); }
    if (view === "education") { $("#view-education").classList.remove("hidden"); renderEducation(); }
  }

  /* ============ dashboard ============ */
  async function loadDashboard() {
    try {
      const [statsRes, patientsRes] = await Promise.all([
        api("/api/stats"),
        api("/api/patients?sort=" + state.sort + "&filter=" + state.filter),
      ]);
      state.stats = statsRes;
      state.patients = patientsRes.patients;
      renderDashboard();
    } catch (e) { /* handled by api() redirect on 401 */ }
  }

  function dialysisTypeLabel(type) {
    return type === "hd" ? t("dialysisTypeHd") : type === "pd" ? t("dialysisTypePd") : "";
  }
  function fitBadge(p) {
    if (p.dialysisStatus === "done") {
      const typeLabel = dialysisTypeLabel(p.dialysisStartType);
      return `<span class="badge done">✅ ${esc(t("statusDone"))}${typeLabel ? " · " + esc(typeLabel) : ""}</span>`;
    }
    const cls = p.fitForPd === "fit" ? "good" : p.fitForPd === "not_fit" ? "critical" : "warning";
    return `<span class="badge ${cls}">${esc(t(p.fitForPd))}</span>`;
  }
  function needsPdCathBadge(p) {
    if (p.dialysisStatus === "done" || !p.needsPdCathInsertion) return "";
    return ` <span class="badge action" title="${esc(t("needsPdCathHint"))}">🗓️ ${esc(t("needsPdCath"))}</span>`;
  }
  function genderLabel(g) { return g ? t(g) : t("notSet"); }
  function egfrPercent(egfr) {
    return Math.max(1, Math.round(egfr));
  }
  function egfrPercentBadge(egfr) {
    if (egfr === null || egfr === undefined) return "";
    const below15 = egfr < 15;
    return ` <span class="egfr-pct${below15 ? " egfr-pct-critical" : ""}" title="${esc(t("egfrPercentNote"))}">${egfrPercent(egfr)}%</span>`;
  }
  function egfrPercentNote(egfr) {
    if (egfr === null || egfr === undefined) return "";
    const below15 = egfr < 15;
    return `<div style="font-size:12px; margin-top:5px; flex-basis:100%; ${below15 ? "color:var(--critical); font-weight:700;" : "color:var(--text-muted); font-weight:400;"}">
      ${esc(t("egfrPercentNote"))} ~${egfrPercent(egfr)}%${below15 ? " — " + esc(t("egfrBelow15Warning")) : ""}
    </div>`;
  }
  function egfrCell(p, withPercent) {
    if (p.egfr === null || p.egfr === undefined) return `<span style="color:var(--text-muted)">${esc(t("notSet"))}</span>`;
    const stageCls = p.stage ? p.stage.status : "neutral";
    const stageLabel = p.stage ? (window.I18N.getLang() === "ar" ? p.stage.labelAr : p.stage.labelEn) : "";
    const base = `${p.egfr} <span class="badge ${stageCls}" title="${esc(stageLabel)}">${esc(p.stage ? p.stage.code : "")}</span>${egfrPercentBadge(p.egfr)}`;
    return withPercent ? base + egfrPercentNote(p.egfr) : base;
  }

  const STAT_ICONS = { brand: "👥", good: "✅", critical: "⛔", warning: "🧪", avg: "📉" };
  function renderStatGrid() {
    const s = state.stats || {};
    const cards = [
      { label: t("statTotal"), value: s.total ?? "–", cls: "brand", icon: "👥" },
      { label: t("statFit"), value: s.fit ?? "–", cls: "good", icon: "✅" },
      { label: t("statNotFit"), value: s.notFit ?? "–", cls: "critical", icon: "⛔" },
      { label: t("statPending"), value: s.pending ?? "–", cls: "warning", icon: "⏳" },
      { label: t("statNeedsPdCath"), value: s.needsPdCath ?? "–", cls: "action", icon: "🗓️" },
      { label: t("statLabsDue"), value: s.labsDue ?? "–", cls: "warning", icon: "🧪" },
      { label: t("statAvgEgfr"), value: s.avgEgfr ?? "–", cls: "brand", icon: "📉" },
      { label: t("statDone"), value: s.done ?? "–", cls: "done", icon: "🏁" },
    ];
    $("#stat-grid").innerHTML = cards.map((c) => `
      <div class="stat-card ${c.cls}">
        <div class="stat-icon">${c.icon}</div>
        <div class="label">${esc(c.label)}</div>
        <div class="value">${esc(c.value)}</div>
      </div>`).join("");
  }

  function tableHead(withRank) {
    return `<tr>
      ${withRank ? `<th></th>` : ""}
      <th>${esc(t("colName"))}</th>
      <th>${esc(t("colGender"))}</th>
      <th>${esc(t("colVisit"))}</th>
      <th>${esc(t("colUrea"))}</th>
      <th>${esc(t("colCreatinine"))}</th>
      <th>${esc(t("colEgfr"))}</th>
      <th>${esc(t("colFit"))}</th>
      <th>${esc(t("colPlan"))}</th>
    </tr>`;
  }
  function fitRowClass(p) {
    if (p.dialysisStatus === "done") return "row-done";
    return p.fitForPd === "fit" ? "row-good" : p.fitForPd === "not_fit" ? "row-critical" : "row-warning";
  }
  function nameSubline(p) {
    const bits = [];
    if (p.phone) bits.push(esc(p.phone));
    const doc = referringDoctorLabel(p);
    if (doc) bits.push(`↗ ${esc(doc)}`);
    return bits.join(" · ");
  }
  function tableRow(p, rank) {
    return `<tr data-id="${p.id}" class="${fitRowClass(p)}">
      ${rank ? `<td><span class="rank-badge">${rank}</span></td>` : ""}
      <td class="name-cell"><span class="n">${esc(p.name)}</span><span class="p">${nameSubline(p)}</span></td>
      <td>${esc(genderLabel(p.gender))}</td>
      <td>${esc(fmtDate(p.visitDate))}</td>
      <td>${p.urea ?? "–"}</td>
      <td>${p.creatinine ?? "–"}</td>
      <td>${egfrCell(p)}</td>
      <td>${fitBadge(p)}${needsPdCathBadge(p)}</td>
      <td>${p.plan ? esc(t(p.plan)) : "–"}</td>
    </tr>`;
  }

  function renderSortSegmented() {
    $all("#sort-segmented button").forEach((b) => {
      b.classList.toggle("active", b.getAttribute("data-sort") === state.sort);
    });
  }

  function renderDashboard() {
    if (!state.stats) return;
    renderStatGrid();

    $("#all-panel-title").textContent = state.filter === "done" ? t("donePatientsTitle") : t("allPatients");
    renderSortSegmented();
    const q = state.search.trim().toLowerCase();
    let list = state.patients;
    if (q) list = list.filter((p) => (p.name || "").toLowerCase().includes(q) || (p.phone || "").includes(q) || (referringDoctorLabel(p) || "").toLowerCase().includes(q));
    $("#all-count").textContent = list.length;
    $("#all-table thead").innerHTML = tableHead(true);
    $("#all-table tbody").innerHTML = list.length
      ? list.map((p, i) => tableRow(p, i + 1)).join("")
      : `<tr><td colspan="9"><div class="empty-state">${esc(state.patients.length ? t("noResults") : t("noPatients"))}</div></td></tr>`;

    $all("#all-table tbody tr[data-id]").forEach((row) => {
      row.addEventListener("click", () => openPatient(Number(row.getAttribute("data-id"))));
    });
  }

  $("#search-box").addEventListener("input", (e) => { state.search = e.target.value; renderDashboard(); });
  $("#filter-select").addEventListener("change", (e) => { state.filter = e.target.value; loadDashboard(); });
  $("#sort-segmented").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-sort]");
    if (!btn) return;
    state.sort = btn.getAttribute("data-sort");
    loadDashboard();
  });

  /* ============ patient detail ============ */
  async function openPatient(id) {
    state.currentPatientId = id;
    navigateTo("patient");
    await renderPatientDetail(id);
  }
  async function renderPatientDetail(id) {
    if (!id) return;
    let patient;
    try {
      const r = await api("/api/patients/" + id);
      patient = r.patient;
    } catch (e) { return; }

    function ynBadge(v) {
      if (v === true) return `<span class="badge good">${esc(t("yes"))}</span>`;
      if (v === false) return `<span class="badge critical">${esc(t("no"))}</span>`;
      return `<span class="badge neutral">${esc(t("notSet"))}</span>`;
    }
    function item(label, value) {
      const isEmpty = value === null || value === undefined || value === "";
      return `<div class="detail-item${isEmpty ? " item-empty" : ""}"><div class="l">${esc(label)}</div><div class="v">${isEmpty ? esc(t("notSet")) : value}</div></div>`;
    }
    function section(titleKey, innerHtml) {
      return `<div class="detail-section"><h3 style="font-size:14px; margin: 22px 0 10px;">${esc(t(titleKey))}</h3><div class="detail-grid" style="margin-bottom:6px;">${innerHtml}</div></div>`;
    }

    const vitals = patient.vitals || {};
    const dialysis = patient.dialysis || {};
    const extraLabs = patient.extraLabs || {};
    const comorbid = patient.comorbid || {};
    const smokingDetail = comorbid.smokingDetail || {};
    const hernia = patient.hernia || {};
    const fluid = patient.fluid || {};
    const teamAssessment = patient.teamAssessment || {};
    const hasExtraLabs = Object.values(extraLabs).some((v) => v !== null && v !== undefined && v !== "");

    const critLabels = {
      chronicConstipation: t("chronicConstipation"), chronicCough: t("chronicCough"),
      hasCaregiver: t("hasCaregiver"), abdominalSurgery: t("abdominalSurgery"), hygiene: t("hygiene"),
    };
    const critHtml = Object.keys(critLabels).map((k) => item(critLabels[k], ynBadge(patient.criteria ? patient.criteria[k] : null))).join("")
      + (patient.otherCriterion && patient.otherCriterion.label ? item(patient.otherCriterion.label, ynBadge(patient.otherCriterion.value)) : "");

    const printedAt = new Date();
    const printedAtStr = printedAt.toLocaleDateString(window.I18N.getLang() === "ar" ? "ar" : "en-GB", { year: "numeric", month: "short", day: "numeric" });

    $("#patient-detail-body").innerHTML = `
      <div class="print-header">
        <div class="print-header-brand">${esc(t("appName"))}</div>
        <div class="print-header-patient">${esc(patient.name)}${patient.fileNumber ? " — " + esc(t("fileNumber")) + " " + esc(patient.fileNumber) : ""}</div>
        <div class="print-header-meta">${esc(t("visitDate"))}: ${fmtDate(patient.visitDate)} &nbsp;•&nbsp; ${esc(t("print"))}: ${esc(printedAtStr)}</div>
      </div>
      ${patient.dialysisStatus === "done" ? `
      <div class="done-banner">
        ✅ ${esc(t("statusDone"))}${dialysisTypeLabel(patient.dialysisStartType) ? " · " + esc(dialysisTypeLabel(patient.dialysisStartType)) : ""}${patient.dialysisStartDate ? " · " + esc(fmtDate(patient.dialysisStartDate)) : ""}
      </div>` : (patient.needsPdCathInsertion ? `
      <div class="done-banner action-banner">
        🗓️ ${esc(t("needsPdCath"))}${patient.pdCathInsertionArrangedDate ? " · " + esc(fmtDate(patient.pdCathInsertionArrangedDate)) : ""}
      </div>` : "")}
      ${section("step1", `
        ${item(t("fullName"), esc(patient.name))}
        ${item(t("phoneNumber"), esc(patient.phone))}
        ${item(t("gender"), esc(genderLabel(patient.gender)))}
        ${item(t("age"), patient.age)}
        ${item(t("dob"), fmtDate(patient.dob))}
        ${item(t("visitDate"), fmtDate(patient.visitDate))}
        ${item(t("patientSource"), patient.patientSource ? t(patient.patientSource === "er" ? "sourceEr" : "sourceOpd") : null)}
        ${item(t("referringDoctor"), esc(referringDoctorLabel(patient)))}
        ${item(t("address"), esc(patient.address))}
        ${item(t("hasFileQuestion"), ynBadge(patient.hasFile))}
        ${patient.hasFile ? item(t("fileNumber"), esc(patient.fileNumber)) : ""}
      `)}

      ${section("vitalsTitle", `
        ${item(t("bp"), esc(vitals.bp))}
        ${item(t("pr"), vitals.pr)}
        ${item(t("weight"), vitals.weight)}
        ${item(t("height"), vitals.height)}
        ${item(t("bsa"), patient.bsa)}
      `)}

      ${section("dialysisHistoryTitle", `
        ${item(t("causeOfEsrd"), dialysis.causeOfEsrd ? esc(dialysis.causeOfEsrd === "cause_other" ? dialysis.causeOfEsrdOther : t(dialysis.causeOfEsrd)) : null)}
        ${item(t("onsetDate"), fmtDate(dialysis.onsetDate))}
        ${item(t("accessType"), dialysis.accessType ? esc(t("access_" + dialysis.accessType)) : null)}
        ${dialysis.accessSide ? item(t("accessSide"), esc(t(dialysis.accessSide))) : ""}
        ${item(t("accessFailure"), ynBadge(dialysis.accessFailure))}
      `)}

      ${section("step2", `
        ${item(t("urea"), patient.urea)}
        ${item(t("creatinine"), patient.creatinine)}
        ${item(t("egfrResult"), egfrCell(patient, true))}
        ${item(t("bsa"), patient.bsa)}
        ${item(patient.hasLabs ? t("labDate") : t("labsDueDate"), fmtDate(patient.hasLabs ? patient.labDate : patient.labsDueDate))}
      `)}

      ${hasExtraLabs ? section("extraLabsToggle", `
        ${item(t("hgb"), extraLabs.hgb)}
        ${item(t("albumin"), extraLabs.albumin)}
        ${item(t("potassium"), extraLabs.k)}
        ${item(t("calcium"), extraLabs.ca)}
        ${item(t("phosphate"), extraLabs.phos)}
        ${item(t("glucose"), extraLabs.glucose)}
        ${item(t("hbsag"), extraLabs.hbsag ? esc(t(extraLabs.hbsag)) : null)}
        ${item(t("hcv"), extraLabs.hcv ? esc(t(extraLabs.hcv)) : null)}
        ${item(t("hiv"), extraLabs.hiv ? esc(t(extraLabs.hiv)) : null)}
        ${item(t("bloodGroup"), esc(extraLabs.bloodGroup))}
      `) : ""}

      ${section("comorbidTitle", `
        ${item(t("diabetesQuestion"), esc(t("diabetes_" + (comorbid.diabetes || "none"))))}
        ${comorbid.diabetesControl ? item(t("diabetesControl"), esc(t("control_" + comorbid.diabetesControl))) : ""}
        ${item(t("hypertensionQuestion"), ynBadge(comorbid.hypertension))}
        ${comorbid.hypertension ? item(t("htnMeds"), esc(comorbid.htnMeds)) : ""}
        ${item(t("cardiacQuestion"), ynBadge(comorbid.cardiac))}
        ${comorbid.cardiac ? item(t("cardiacDx"), esc(comorbid.cardiacDx)) : ""}
        ${comorbid.cardiac ? item(t("ef"), comorbid.ef) : ""}
        ${item(t("chronicRespiratoryQuestion"), ynBadge(comorbid.chronicRespiratory))}
        ${item(t("smoker"), ynBadge(patient.criteria ? patient.criteria.smoker : null))}
        ${item(t("cigarettesPerDay"), smokingDetail.cigarettesPerDay)}
        ${item(t("yearsSmoking"), smokingDetail.yearsSmoking)}
        ${item(t("quitDate"), fmtDate(smokingDetail.quitDate))}
      `)}

      ${section("step4", critHtml + (patient.abdominalSurgeryDetail ? item(t("abdominalSurgeryDetail"), esc(patient.abdominalSurgeryDetail)) : ""))}

      ${section("herniaQuestion", `
        ${item(t("herniaQuestion"), ynBadge(hernia.present))}
        ${hernia.type ? item(t("herniaType"), esc(t("hernia_" + hernia.type))) : ""}
      `)}

      ${section("fluidTitle", `
        ${item(t("fluidIntake"), esc(fluid.intakeDescription))}
        ${item(t("fastFoodFrequency"), fluid.fastFoodFrequency ? esc(t("freq_" + fluid.fastFoodFrequency)) : null)}
        ${item(t("priorFluidOverloadAdmission"), ynBadge(fluid.priorFluidOverloadAdmission))}
        ${fluid.priorFluidOverloadAdmission ? item(t("admissionsLast6Months"), fluid.admissionsLast6Months) : ""}
      `)}

      ${patient.medications && patient.medications.length ? `
      <h3 style="font-size:14px; margin: 22px 0 10px;">${esc(t("medicationsTitle"))}</h3>
      <div class="table-wrap"><table class="patients"><thead><tr>
        <th>${esc(t("medName"))}</th><th>${esc(t("medDose"))}</th><th>${esc(t("medRoute"))}</th><th>${esc(t("medFrequency"))}</th>
      </tr></thead><tbody>
        ${patient.medications.map((m) => `<tr><td>${esc(m.name)}</td><td>${esc(m.dose)}</td><td>${esc(m.route)}</td><td>${esc(m.frequency)}</td></tr>`).join("")}
      </tbody></table></div>
      ` : ""}

      ${section("step6", `
        ${item(t("fitForPdQuestion"), fitBadge(patient))}
        ${item(t("planQuestion"), patient.plan ? esc(t(patient.plan)) : null)}
        ${item(t("followUpDate"), fmtDate(patient.followUpDate))}
        ${item(t("needsPdCathInsertion"), ynBadge(patient.needsPdCathInsertion))}
        ${patient.needsPdCathInsertion ? item(t("pdCathInsertionArrangedDate"), fmtDate(patient.pdCathInsertionArrangedDate)) : ""}
        ${item(t("pdCatheterInserted"), ynBadge(patient.pdCatheterInserted))}
        ${patient.pdCatheterInserted ? item(t("pdCatheterInsertedDate"), fmtDate(patient.pdCatheterInsertedDate)) : ""}
      `)}

      ${(teamAssessment.surgeonNotes || teamAssessment.nephrologistNotes || teamAssessment.pdCoordinatorName || teamAssessment.acceptedByPdCoordinator !== null) ? `
      <h3 style="font-size:14px; margin: 22px 0 10px;">${esc(t("teamAssessmentTitle"))}</h3>
      <div class="detail-grid" style="margin-bottom:6px;">
        ${item(t("pdCoordinatorName"), esc(teamAssessment.pdCoordinatorName))}
        ${item(t("acceptedByPdCoordinator"), ynBadge(teamAssessment.acceptedByPdCoordinator))}
        ${item(t("acceptedBySurgeon"), ynBadge(teamAssessment.acceptedBySurgeon))}
        ${item(t("acceptedByNephrology"), ynBadge(teamAssessment.acceptedByNephrology))}
      </div>
      ${teamAssessment.surgeonNotes ? `<div class="detail-item" style="margin-bottom:8px;"><div class="l">${esc(t("surgeonNotes"))}</div><div class="v" style="font-weight:400;">${esc(teamAssessment.surgeonNotes)}</div></div>` : ""}
      ${teamAssessment.nephrologistNotes ? `<div class="detail-item"><div class="l">${esc(t("nephrologistNotes"))}</div><div class="v" style="font-weight:400;">${esc(teamAssessment.nephrologistNotes)}</div></div>` : ""}
      ` : ""}

      ${patient.notes ? `<div class="detail-item" style="margin-top:14px;"><div class="l">${esc(t("notes"))}</div><div class="v" style="font-weight:400;">${esc(patient.notes)}</div></div>` : ""}

      <p style="font-size:12px; color:var(--text-muted); margin-top:18px;">
        ${esc(t("recordedOn"))}: ${esc(fmtDate(patient.createdAt))} · ${esc(t("lastUpdated"))}: ${esc(fmtDate(patient.updatedAt))}
      </p>
    `;

    $("#btn-back-dashboard").onclick = () => navigateTo("dashboard");
    $("#btn-print").onclick = () => window.print();
    $("#btn-edit-patient").onclick = () => {
      state.wizard = { step: 1, editingId: patient.id, data: normalizeForForm(patient) };
      navigateTo("form", { keep: true });
    };
    $("#btn-delete-patient").onclick = () => {
      $("#delete-confirm-text").textContent = t("confirmDelete");
      $("#modal-delete").classList.remove("hidden");
      $("#delete-confirm").onclick = async () => {
        await api("/api/patients/" + patient.id, { method: "DELETE" });
        $("#modal-delete").classList.add("hidden");
        toast(t("saved"));
        navigateTo("dashboard");
      };
    };
  }
  $("#delete-cancel").addEventListener("click", () => $("#modal-delete").classList.add("hidden"));

  function deepMerge(defaults, override) {
    if (override === null || override === undefined) return defaults;
    if (typeof defaults !== "object" || Array.isArray(defaults) || defaults instanceof Object === false) {
      return override;
    }
    const out = Object.assign({}, defaults);
    Object.keys(defaults).forEach((k) => {
      if (override[k] === undefined) return;
      if (defaults[k] && typeof defaults[k] === "object" && !Array.isArray(defaults[k]) && override[k] && typeof override[k] === "object") {
        out[k] = deepMerge(defaults[k], override[k]);
      } else {
        out[k] = override[k] === null ? (typeof defaults[k] === "string" ? "" : override[k]) : override[k];
      }
    });
    return out;
  }

  function normalizeForForm(p) {
    const base = emptyPatient();
    const merged = deepMerge(base, p);
    merged.visitDate = p.visitDate || todayIso();
    merged.medications = Array.isArray(p.medications) ? p.medications.slice() : [];
    merged.showExtraLabs = !!(p.extraLabs && Object.values(p.extraLabs).some((v) => v !== null && v !== ""));
    return merged;
  }

  /* ============ wizard ============ */
  const STEP_KEYS = ["step1", "step2", "step3", "step4", "step5", "step6"];
  const TOTAL_STEPS = STEP_KEYS.length;

  function setDeep(obj, path, value) {
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) cur = cur[parts[i]];
    cur[parts[parts.length - 1]] = value;
  }
  function getDeep(obj, path) {
    return path.split(".").reduce((o, k) => (o == null ? o : o[k]), obj);
  }

  function ynGroup(fieldPath, value) {
    return `<div class="yn-toggle" data-yn-field="${esc(fieldPath)}">
      <button type="button" class="yes ${value === true ? "active" : ""}" data-value="true">${esc(t("yes"))}</button>
      <button type="button" class="no ${value === false ? "active" : ""}" data-value="false">${esc(t("no"))}</button>
    </div>`;
  }
  function criterionRow(fieldPath, label, value) {
    return `<div class="criterion-row"><span class="label">${esc(label)}</span>${ynGroup(fieldPath, value)}</div>`;
  }
  function choiceCards(fieldPath, options, currentValue) {
    return `<div class="choice-group">${options.map(([val, label]) => `
      <div class="choice-card ${currentValue === val ? "selected" : ""}" data-choice-field="${esc(fieldPath)}" data-value="${esc(val)}">
        <div class="t">${esc(label)}</div>
      </div>`).join("")}</div>`;
  }

  function bsaLiveHtml(d) {
    const w = Number(d.vitals.weight), h = Number(d.vitals.height);
    const bsa = w && h ? Math.round(Math.sqrt((h * w) / 3600) * 100) / 100 : null;
    return bsa !== null
      ? `<div class="egfr-result" style="padding:12px 16px;"><div><span class="num" style="font-size:20px;">${bsa}</span> <span class="unit">m²</span></div><div class="note">${esc(t("bsaAuto"))}</div></div>`
      : "";
  }
  function egfrLiveHtml(d) {
    const eg = (d.creatinine && d.age && d.gender) ? window.GFR.calcEGFR(d.creatinine, d.age, d.gender) : null;
    const stage = eg !== null ? window.GFR.gfrStage(eg) : null;
    return `<div class="egfr-result ${eg !== null && eg < 15 ? "egfr-critical" : ""}">
      ${eg !== null ? `
        <div><span class="num">${eg}</span> <span class="unit">mL/min/1.73m²</span>${egfrPercentBadge(eg)}</div>
        <span class="badge ${stage.status}">${esc(stage.code)} · ${esc(window.I18N.getLang() === "ar" ? stage.labelAr : stage.labelEn)}</span>
        ${egfrPercentNote(eg)}
      ` : `<div style="color:var(--text-muted); font-size:13.5px;">${esc(t("egfrNeedsInfo"))}</div>`}
      <div class="note">${esc(t("egfrFormulaNote"))}</div>
    </div>`;
  }

  function renderWizard() {
    const w = state.wizard;
    $("#wizard-title").textContent = w.editingId ? t("wizardTitleEdit") : t("wizardTitleNew");
    $("#wizard-steps").innerHTML = STEP_KEYS.map((key, idx) => {
      const n = idx + 1;
      const cls = n === w.step ? "active" : n < w.step ? "done" : "";
      return `<button type="button" class="wizard-step ${cls}" data-step="${n}">${n}. ${esc(t(key))}</button>`;
    }).join("");
    $all(".wizard-step").forEach((b) => b.addEventListener("click", () => {
      const n = Number(b.getAttribute("data-step"));
      w.step = n; renderWizard();
    }));

    $("#wizard-body").innerHTML = renderWizardStep(w.step, w.data);
    bindWizardStepEvents(w.step);

    $("#wizard-back").textContent = t("back");
    $("#wizard-back").style.visibility = w.step === 1 ? "hidden" : "visible";
    $("#wizard-next").textContent = w.step === TOTAL_STEPS ? t("savePatient") : t("next");
    $("#wizard-cancel").textContent = t("cancel");
    $("#wizard-skip").style.visibility = w.step === TOTAL_STEPS ? "hidden" : "visible";
  }

  function rerenderStep() {
    const w = state.wizard;
    $("#wizard-body").innerHTML = renderWizardStep(w.step, w.data);
    bindWizardStepEvents(w.step);
  }

  function renderWizardStep(step, d) {
    if (step === 1) {
      return `
        <div class="form-grid">
          <div class="field">
            <label>${esc(t("fullName"))} *</label>
            <input type="text" data-field="name" value="${esc(d.name)}" />
          </div>
          <div class="field">
            <label>${esc(t("phoneNumber"))}</label>
            <input type="tel" data-field="phone" value="${esc(d.phone)}" />
          </div>
          <div class="field">
            <label>${esc(t("gender"))}</label>
            <select data-field="gender">
              <option value="">${esc(t("selectGender"))}</option>
              <option value="male" ${d.gender === "male" ? "selected" : ""}>${esc(t("male"))}</option>
              <option value="female" ${d.gender === "female" ? "selected" : ""}>${esc(t("female"))}</option>
            </select>
          </div>
          <div class="field">
            <label>${esc(t("age"))}</label>
            <input type="number" min="0" max="120" data-field="age" value="${esc(d.age)}" />
          </div>
          <div class="field">
            <label>${esc(t("dob"))} <span style="color:var(--text-muted); font-weight:400;">(${esc(t("optional"))})</span></label>
            <input type="date" data-field="dob" value="${esc(d.dob)}" />
          </div>
          <div class="field">
            <label>${esc(t("visitDate"))}</label>
            <input type="date" data-field="visitDate" value="${esc(d.visitDate)}" />
          </div>
          <div class="field">
            <label>${esc(t("patientSource"))}</label>
            ${choiceCards("patientSource", [["er", t("sourceEr")], ["opd", t("sourceOpd")]], d.patientSource)}
          </div>
          <div class="field">
            <label>${esc(t("referringDoctor"))}</label>
            <select data-field="referringDoctor">
              <option value="">${esc(t("selectDoctor"))}</option>
              ${REFERRING_DOCTORS.map((g) => `<optgroup label="${esc(g.hospital)}">${g.doctors.map((doc) => `<option value="${doc.key}" ${d.referringDoctor === doc.key ? "selected" : ""}>${esc(doc.label)}</option>`).join("")}</optgroup>`).join("")}
              <option value="other" ${d.referringDoctor === "other" ? "selected" : ""}>${esc(t("referringDoctorOtherOption"))}</option>
            </select>
          </div>
          ${d.referringDoctor === "other" ? `
          <div class="field">
            <label>${esc(t("referringDoctorOtherLabel"))}</label>
            <input type="text" placeholder="${esc(t("referringDoctorPlaceholder"))}" data-field="referringDoctorOther" value="${esc(d.referringDoctorOther)}" />
          </div>` : ""}
          <div class="field" style="grid-column: 1 / -1;">
            <label>${esc(t("address"))}</label>
            <input type="text" data-field="address" value="${esc(d.address)}" />
          </div>
        </div>

        <div class="criterion-row" style="margin-top:6px;">
          <span class="label">${esc(t("hasFileQuestion"))}</span>
          ${ynGroup("hasFile", d.hasFile)}
        </div>
        ${d.hasFile ? `
        <div class="form-grid cols-1">
          <div class="field"><label>${esc(t("fileNumber"))}</label><input type="text" data-field="fileNumber" value="${esc(d.fileNumber)}" /></div>
        </div>` : ""}

        <h3 style="font-size:14px; margin: 22px 0 12px;">${esc(t("vitalsTitle"))}</h3>
        <div class="form-grid">
          <div class="field"><label>${esc(t("bp"))}</label><input type="text" placeholder="120/80" data-field="vitals.bp" value="${esc(d.vitals.bp)}" /></div>
          <div class="field"><label>${esc(t("pr"))}</label><input type="number" min="0" data-field="vitals.pr" value="${esc(d.vitals.pr)}" /></div>
          <div class="field"><label>${esc(t("weight"))}</label><input type="number" step="0.1" min="0" data-field="vitals.weight" data-live="bsa" value="${esc(d.vitals.weight)}" /></div>
          <div class="field"><label>${esc(t("height"))}</label><input type="number" step="0.1" min="0" data-field="vitals.height" data-live="bsa" value="${esc(d.vitals.height)}" /></div>
        </div>
        <div id="bsa-live-box">${bsaLiveHtml(d)}</div>
      `;
    }
    if (step === 2) {
      const causeOptions = ["cause_diabetic", "cause_hypertensive", "cause_gn", "cause_pkd", "cause_obstructive", "cause_unknown", "cause_other"];
      return `
        <h3 style="font-size:14px; margin: 0 0 12px;">${esc(t("dialysisHistoryTitle"))}</h3>
        <div class="form-grid">
          <div class="field">
            <label>${esc(t("causeOfEsrd"))}</label>
            <select data-field="dialysis.causeOfEsrd">
              <option value="">${esc(t("selectCause"))}</option>
              ${causeOptions.map((k) => `<option value="${k}" ${d.dialysis.causeOfEsrd === k ? "selected" : ""}>${esc(t(k))}</option>`).join("")}
            </select>
          </div>
          ${d.dialysis.causeOfEsrd === "cause_other" ? `
          <div class="field"><label>${esc(t("causeOfEsrdOtherPlaceholder"))}</label><input type="text" data-field="dialysis.causeOfEsrdOther" value="${esc(d.dialysis.causeOfEsrdOther)}" /></div>
          ` : ""}
          <div class="field"><label>${esc(t("onsetDate"))}</label><input type="date" data-field="dialysis.onsetDate" value="${esc(d.dialysis.onsetDate)}" /></div>
        </div>

        <div class="field" style="margin-top:14px;">
          <label>${esc(t("accessType"))}</label>
          ${choiceCards("dialysis.accessType", [
            ["avf", t("access_avf")], ["temp_catheter", t("access_temp_catheter")],
            ["perm_catheter", t("access_perm_catheter")], ["none", t("access_none")],
          ], d.dialysis.accessType)}
        </div>
        ${(d.dialysis.accessType === "temp_catheter" || d.dialysis.accessType === "perm_catheter") ? `
        <div class="field" style="margin-top:14px;">
          <label>${esc(t("accessSide"))}</label>
          ${choiceCards("dialysis.accessSide", [["left", t("left")], ["right", t("right")]], d.dialysis.accessSide)}
        </div>` : ""}
        <div class="criterion-row" style="margin-top:14px;">
          <span class="label">${esc(t("accessFailure"))}</span>
          ${ynGroup("dialysis.accessFailure", d.dialysis.accessFailure)}
        </div>

        <h3 style="font-size:14px; margin: 24px 0 12px;">${esc(t("step2"))} — ${esc(t("urea"))} / ${esc(t("creatinine"))}</h3>
        <div class="choice-group" style="margin-bottom:20px;">
          <div class="choice-card ${d.hasLabs ? "selected" : ""}" data-choice-field="hasLabs" data-value="true">
            <div class="t">${esc(t("yesHasLabs"))}</div>
          </div>
          <div class="choice-card ${!d.hasLabs ? "selected" : ""}" data-choice-field="hasLabs" data-value="false">
            <div class="t">${esc(t("noHasLabs"))}</div>
          </div>
        </div>
        ${d.hasLabs ? `
        <div class="form-grid">
          <div class="field"><label>${esc(t("urea"))}</label><input type="number" step="0.1" min="0" data-field="urea" data-live="egfr" value="${esc(d.urea)}" /></div>
          <div class="field"><label>${esc(t("creatinine"))}</label><input type="number" step="1" min="0" data-field="creatinine" data-live="egfr" value="${esc(d.creatinine)}" /></div>
          <div class="field"><label>${esc(t("labDate"))}</label><input type="date" data-field="labDate" value="${esc(d.labDate)}" /></div>
        </div>
        <div id="egfr-live-box">${egfrLiveHtml(d)}</div>

        <button type="button" class="btn btn-ghost btn-sm" id="toggle-extra-labs" style="margin-top:16px;">
          ${d.showExtraLabs ? esc(t("showLess")) : esc(t("extraLabsToggle"))}
        </button>
        ${d.showExtraLabs ? `
        <div class="form-grid" style="margin-top:14px;">
          <div class="field"><label>${esc(t("hgb"))}</label><input type="number" step="0.1" data-field="extraLabs.hgb" value="${esc(d.extraLabs.hgb)}" /></div>
          <div class="field"><label>${esc(t("albumin"))}</label><input type="number" step="0.1" data-field="extraLabs.albumin" value="${esc(d.extraLabs.albumin)}" /></div>
          <div class="field"><label>${esc(t("potassium"))}</label><input type="number" step="0.1" data-field="extraLabs.k" value="${esc(d.extraLabs.k)}" /></div>
          <div class="field"><label>${esc(t("calcium"))}</label><input type="number" step="0.1" data-field="extraLabs.ca" value="${esc(d.extraLabs.ca)}" /></div>
          <div class="field"><label>${esc(t("phosphate"))}</label><input type="number" step="0.1" data-field="extraLabs.phos" value="${esc(d.extraLabs.phos)}" /></div>
          <div class="field"><label>${esc(t("glucose"))}</label><input type="number" step="1" data-field="extraLabs.glucose" value="${esc(d.extraLabs.glucose)}" /></div>
          <div class="field"><label>${esc(t("hbsag"))}</label>
            <select data-field="extraLabs.hbsag"><option value="">—</option><option value="negative" ${d.extraLabs.hbsag === "negative" ? "selected" : ""}>${esc(t("negative"))}</option><option value="positive" ${d.extraLabs.hbsag === "positive" ? "selected" : ""}>${esc(t("positive"))}</option></select>
          </div>
          <div class="field"><label>${esc(t("hcv"))}</label>
            <select data-field="extraLabs.hcv"><option value="">—</option><option value="negative" ${d.extraLabs.hcv === "negative" ? "selected" : ""}>${esc(t("negative"))}</option><option value="positive" ${d.extraLabs.hcv === "positive" ? "selected" : ""}>${esc(t("positive"))}</option></select>
          </div>
          <div class="field"><label>${esc(t("hiv"))}</label>
            <select data-field="extraLabs.hiv"><option value="">—</option><option value="negative" ${d.extraLabs.hiv === "negative" ? "selected" : ""}>${esc(t("negative"))}</option><option value="positive" ${d.extraLabs.hiv === "positive" ? "selected" : ""}>${esc(t("positive"))}</option></select>
          </div>
          <div class="field"><label>${esc(t("bloodGroup"))}</label><input type="text" placeholder="O+" data-field="extraLabs.bloodGroup" value="${esc(d.extraLabs.bloodGroup)}" /></div>
        </div>` : ""}
        ` : `
        <div class="form-grid cols-1">
          <div class="field"><label>${esc(t("labsDueDate"))}</label><input type="date" data-field="labsDueDate" value="${esc(d.labsDueDate)}" /></div>
        </div>
        `}
      `;
    }
    if (step === 3) {
      return `
        <h3 style="font-size:14px; margin: 0 0 12px;">${esc(t("comorbidTitle"))}</h3>
        <div class="field">
          <label>${esc(t("diabetesQuestion"))}</label>
          ${choiceCards("comorbid.diabetes", [
            ["none", t("diabetes_none")], ["insulin", t("diabetes_insulin")], ["oral", t("diabetes_oral")],
          ], d.comorbid.diabetes)}
        </div>
        ${d.comorbid.diabetes !== "none" ? `
        <div class="field" style="margin-top:14px;">
          <label>${esc(t("diabetesControl"))}</label>
          ${choiceCards("comorbid.diabetesControl", [["good", t("control_good")], ["poor", t("control_poor")]], d.comorbid.diabetesControl)}
        </div>` : ""}

        ${criterionRow("comorbid.hypertension", t("hypertensionQuestion"), d.comorbid.hypertension)}
        ${d.comorbid.hypertension === true ? `
        <div class="form-grid cols-1" style="margin-bottom:14px;">
          <div class="field"><label>${esc(t("htnMeds"))}</label><input type="text" data-field="comorbid.htnMeds" value="${esc(d.comorbid.htnMeds)}" /></div>
        </div>` : ""}

        ${criterionRow("comorbid.cardiac", t("cardiacQuestion"), d.comorbid.cardiac)}
        ${d.comorbid.cardiac === true ? `
        <div class="form-grid" style="margin-bottom:14px;">
          <div class="field"><label>${esc(t("cardiacDx"))}</label><input type="text" data-field="comorbid.cardiacDx" value="${esc(d.comorbid.cardiacDx)}" /></div>
          <div class="field"><label>${esc(t("ef"))}</label><input type="number" min="0" max="100" data-field="comorbid.ef" value="${esc(d.comorbid.ef)}" /></div>
        </div>` : ""}

        ${criterionRow("comorbid.chronicRespiratory", t("chronicRespiratoryQuestion"), d.comorbid.chronicRespiratory)}
        ${criterionRow("criteria.smoker", t("smoker"), d.criteria.smoker)}
        <div class="form-grid" style="margin-bottom:6px;">
          <div class="field"><label>${esc(t("cigarettesPerDay"))}</label><input type="number" min="0" data-field="comorbid.smokingDetail.cigarettesPerDay" value="${esc(d.comorbid.smokingDetail.cigarettesPerDay)}" /></div>
          <div class="field"><label>${esc(t("yearsSmoking"))}</label><input type="number" min="0" data-field="comorbid.smokingDetail.yearsSmoking" value="${esc(d.comorbid.smokingDetail.yearsSmoking)}" /></div>
          <div class="field"><label>${esc(t("quitDate"))}</label><input type="date" data-field="comorbid.smokingDetail.quitDate" value="${esc(d.comorbid.smokingDetail.quitDate)}" /></div>
        </div>
      `;
    }
    if (step === 4) {
      const items = [
        ["criteria.chronicConstipation", "chronicConstipation"], ["criteria.chronicCough", "chronicCough"],
        ["criteria.hasCaregiver", "hasCaregiver"], ["criteria.abdominalSurgery", "abdominalSurgery"], ["criteria.hygiene", "hygiene"],
      ];
      const rows = items.map(([path, label]) => criterionRow(path, t(label), getDeep(d, path))).join("");
      return `
        <p style="font-size:13px; color:var(--text-muted); margin-bottom:14px;">${esc(t("pdCriteriaIntro"))}</p>
        ${rows}
        ${d.criteria.abdominalSurgery === true ? `
        <div class="form-grid cols-1" style="margin-bottom:14px;">
          <div class="field"><label>${esc(t("abdominalSurgeryDetail"))}</label><input type="text" data-field="abdominalSurgeryDetail" value="${esc(d.abdominalSurgeryDetail)}" /></div>
        </div>` : ""}

        ${criterionRow("hernia.present", t("herniaQuestion"), d.hernia.present)}
        ${d.hernia.present === true ? `
        <div class="field" style="margin-bottom:14px;">
          <label>${esc(t("herniaType"))}</label>
          ${choiceCards("hernia.type", [["umbilical", t("hernia_umbilical")], ["paraumbilical", t("hernia_paraumbilical")], ["inguinal", t("hernia_inguinal")]], d.hernia.type)}
        </div>` : ""}

        <div class="criterion-row" style="flex-wrap:wrap;">
          <input type="text" data-field="otherCriterion.label" placeholder="${esc(t("otherCriterionPlaceholder"))}"
            value="${esc(d.otherCriterion.label)}" style="flex:1; min-width:180px; padding:8px 10px; border-radius:8px; border:1px solid var(--gridline);" />
          ${ynGroup("otherCriterion.value", d.otherCriterion.value)}
        </div>

        <h3 style="font-size:14px; margin: 22px 0 12px;">${esc(t("fluidTitle"))}</h3>
        <div class="form-grid" style="margin-bottom:8px;">
          <div class="field"><label>${esc(t("fluidIntake"))}</label><input type="text" placeholder="${esc(t("fluidIntakePlaceholder"))}" data-field="fluid.intakeDescription" value="${esc(d.fluid.intakeDescription)}" /></div>
          <div class="field">
            <label>${esc(t("fastFoodFrequency"))}</label>
            <select data-field="fluid.fastFoodFrequency">
              <option value="">${esc(t("selectGender"))}</option>
              <option value="rarely" ${d.fluid.fastFoodFrequency === "rarely" ? "selected" : ""}>${esc(t("freq_rarely"))}</option>
              <option value="sometimes" ${d.fluid.fastFoodFrequency === "sometimes" ? "selected" : ""}>${esc(t("freq_sometimes"))}</option>
              <option value="often" ${d.fluid.fastFoodFrequency === "often" ? "selected" : ""}>${esc(t("freq_often"))}</option>
            </select>
          </div>
        </div>
        ${criterionRow("fluid.priorFluidOverloadAdmission", t("priorFluidOverloadAdmission"), d.fluid.priorFluidOverloadAdmission)}
        ${d.fluid.priorFluidOverloadAdmission === true ? `
        <div class="form-grid cols-1">
          <div class="field"><label>${esc(t("admissionsLast6Months"))}</label><input type="number" min="0" data-field="fluid.admissionsLast6Months" value="${esc(d.fluid.admissionsLast6Months)}" /></div>
        </div>` : ""}
      `;
    }
    if (step === 5) {
      const rows = d.medications.map((m, i) => `
        <div class="form-grid" style="grid-template-columns: 2fr 1fr 1fr 1fr auto; align-items:end; margin-bottom:10px;" data-med-row="${i}">
          <div class="field" style="margin-bottom:0;"><label>${esc(t("medName"))}</label><input type="text" data-med-field="name" data-med-index="${i}" value="${esc(m.name)}" /></div>
          <div class="field" style="margin-bottom:0;"><label>${esc(t("medDose"))}</label><input type="text" data-med-field="dose" data-med-index="${i}" value="${esc(m.dose)}" /></div>
          <div class="field" style="margin-bottom:0;"><label>${esc(t("medRoute"))}</label><input type="text" data-med-field="route" data-med-index="${i}" value="${esc(m.route)}" /></div>
          <div class="field" style="margin-bottom:0;"><label>${esc(t("medFrequency"))}</label><input type="text" data-med-field="frequency" data-med-index="${i}" value="${esc(m.frequency)}" /></div>
          <button type="button" class="btn btn-danger btn-sm" data-med-remove="${i}">${esc(t("removeMedication"))}</button>
        </div>
      `).join("");
      return `
        <h3 style="font-size:14px; margin: 0 0 12px;">${esc(t("medicationsTitle"))}</h3>
        <div id="med-rows">${rows || `<p style="color:var(--text-muted); font-size:13.5px;">${esc(t("noMedications"))}</p>`}</div>
        <button type="button" class="btn btn-ghost btn-sm" id="add-medication">${esc(t("addMedication"))}</button>
      `;
    }
    if (step === 6) {
      const fitOptions = [
        ["fit", t("fit")], ["not_fit", t("not_fit")], ["pending", t("pending")],
      ];
      return `
        <div class="field">
          <label>${esc(t("fitForPdQuestion"))}</label>
          ${choiceCards("fitForPd", fitOptions, d.fitForPd)}
        </div>
        <div class="form-grid" style="margin-top:18px;">
          <div class="field">
            <label>${esc(t("planQuestion"))}</label>
            <select data-field="plan">
              <option value="">${esc(t("selectPlan"))}</option>
              <option value="follow_up" ${d.plan === "follow_up" ? "selected" : ""}>${esc(t("follow_up"))}</option>
              <option value="pd_cath_insertion" ${d.plan === "pd_cath_insertion" ? "selected" : ""}>${esc(t("pd_cath_insertion"))}</option>
              <option value="pre_hd_clinic" ${d.plan === "pre_hd_clinic" ? "selected" : ""}>${esc(t("pre_hd_clinic"))}</option>
            </select>
          </div>
          <div class="field">
            <label>${esc(t("followUpDate"))}</label>
            <input type="date" data-field="followUpDate" value="${esc(d.followUpDate)}" />
          </div>
        </div>

        <div class="criterion-row" style="margin-top:14px;">
          <span class="label">${esc(t("needsPdCathInsertion"))}</span>
          ${ynGroup("needsPdCathInsertion", d.needsPdCathInsertion)}
        </div>
        ${d.needsPdCathInsertion === true ? `
        <div class="form-grid cols-1">
          <div class="field"><label>${esc(t("pdCathInsertionArrangedDate"))}</label><input type="date" data-field="pdCathInsertionArrangedDate" value="${esc(d.pdCathInsertionArrangedDate)}" /></div>
        </div>
        <p style="font-size:12.5px; color:var(--action); font-weight:600; margin-top:-4px; margin-bottom:14px;">${esc(t("needsPdCathHint"))}</p>
        ` : ""}

        <div class="criterion-row" style="margin-top:14px;">
          <span class="label">${esc(t("pdCatheterInserted"))}</span>
          ${ynGroup("pdCatheterInserted", d.pdCatheterInserted)}
        </div>
        ${d.pdCatheterInserted === true ? `
        <div class="form-grid cols-1">
          <div class="field"><label>${esc(t("pdCatheterInsertedDate"))}</label><input type="date" data-field="pdCatheterInsertedDate" value="${esc(d.pdCatheterInsertedDate)}" /></div>
        </div>` : ""}

        <h3 style="font-size:14px; margin: 22px 0 12px;">${esc(t("dialysisStatusTitle"))}</h3>
        <div class="field">
          ${choiceCards("dialysisStatus", [["active", t("statusActive")], ["done", t("statusDone")]], d.dialysisStatus)}
        </div>
        ${d.dialysisStatus === "done" ? `
        <div class="form-grid" style="margin-top:14px;">
          <div class="field">
            <label>${esc(t("dialysisStartType"))}</label>
            ${choiceCards("dialysisStartType", [["hd", t("dialysisTypeHd")], ["pd", t("dialysisTypePd")]], d.dialysisStartType)}
          </div>
          <div class="field"><label>${esc(t("dialysisStartDate"))}</label><input type="date" data-field="dialysisStartDate" value="${esc(d.dialysisStartDate)}" /></div>
        </div>
        <p style="font-size:12.5px; color:var(--done); font-weight:600; margin-top:10px;">${esc(t("dialysisDoneHint"))}</p>
        ` : ""}

        <h3 style="font-size:14px; margin: 22px 0 12px;">${esc(t("teamAssessmentTitle"))}</h3>
        <div class="field">
          <label>${esc(t("surgeonNotes"))}</label>
          <textarea rows="3" data-field="teamAssessment.surgeonNotes">${esc(d.teamAssessment.surgeonNotes)}</textarea>
        </div>
        <div class="field" style="margin-top:14px;">
          <label>${esc(t("nephrologistNotes"))}</label>
          <textarea rows="3" data-field="teamAssessment.nephrologistNotes">${esc(d.teamAssessment.nephrologistNotes)}</textarea>
        </div>

        <div class="field" style="margin-top:14px;">
          <label>${esc(t("pdCoordinatorName"))}</label>
          <input type="text" placeholder="${esc(t("pdCoordinatorNamePlaceholder"))}" data-field="teamAssessment.pdCoordinatorName" value="${esc(d.teamAssessment.pdCoordinatorName)}" />
        </div>

        <h3 style="font-size:14px; margin: 22px 0 12px;">${esc(t("teamSignOff"))}</h3>
        ${criterionRow("teamAssessment.acceptedByPdCoordinator", t("acceptedByPdCoordinator"), d.teamAssessment.acceptedByPdCoordinator)}
        ${criterionRow("teamAssessment.acceptedBySurgeon", t("acceptedBySurgeon"), d.teamAssessment.acceptedBySurgeon)}
        ${criterionRow("teamAssessment.acceptedByNephrology", t("acceptedByNephrology"), d.teamAssessment.acceptedByNephrology)}

        <div class="field" style="margin-top:18px;">
          <label>${esc(t("notes"))}</label>
          <textarea rows="4" data-field="notes" placeholder="${esc(t("notesPlaceholder"))}">${esc(d.notes)}</textarea>
        </div>
      `;
    }
    return "";
  }

  function bindWizardStepEvents(step) {
    const d = state.wizard.data;
    const body = $("#wizard-body");

    $all("[data-field]", body).forEach((el) => {
      el.addEventListener("input", () => {
        setDeep(d, el.getAttribute("data-field"), el.value);
        const live = el.getAttribute("data-live");
        if (live === "bsa") $("#bsa-live-box").innerHTML = bsaLiveHtml(d);
        if (live === "egfr") $("#egfr-live-box").innerHTML = egfrLiveHtml(d);
      });
      if (el.tagName === "SELECT") {
        el.addEventListener("change", () => { setDeep(d, el.getAttribute("data-field"), el.value); rerenderStep(); });
      }
    });

    $all("[data-choice-field]", body).forEach((card) => {
      card.addEventListener("click", () => {
        const field = card.getAttribute("data-choice-field");
        const raw = card.getAttribute("data-value");
        const value = raw === "true" ? true : raw === "false" ? false : raw;
        setDeep(d, field, value);
        rerenderStep();
      });
    });

    $all("[data-yn-field]", body).forEach((group) => {
      const path = group.getAttribute("data-yn-field");
      $all("button", group).forEach((btn) => {
        btn.addEventListener("click", () => {
          setDeep(d, path, btn.getAttribute("data-value") === "true");
          rerenderStep();
        });
      });
    });

    const extraLabsBtn = $("#toggle-extra-labs", body);
    if (extraLabsBtn) extraLabsBtn.addEventListener("click", () => { d.showExtraLabs = !d.showExtraLabs; rerenderStep(); });

    $all("[data-med-field]", body).forEach((el) => {
      el.addEventListener("input", () => {
        const i = Number(el.getAttribute("data-med-index"));
        d.medications[i][el.getAttribute("data-med-field")] = el.value;
      });
    });
    $all("[data-med-remove]", body).forEach((btn) => {
      btn.addEventListener("click", () => {
        d.medications.splice(Number(btn.getAttribute("data-med-remove")), 1);
        rerenderStep();
      });
    });
    const addMedBtn = $("#add-medication", body);
    if (addMedBtn) addMedBtn.addEventListener("click", () => {
      d.medications.push({ name: "", dose: "", route: "", frequency: "" });
      rerenderStep();
    });
  }

  $("#wizard-back").addEventListener("click", () => {
    if (state.wizard.step > 1) { state.wizard.step--; renderWizard(); }
  });
  $("#wizard-cancel").addEventListener("click", () => navigateTo("dashboard"));
  $("#wizard-skip").addEventListener("click", () => {
    const w = state.wizard;
    if (w.step < TOTAL_STEPS) { w.step++; renderWizard(); }
  });
  $("#wizard-next").addEventListener("click", async () => {
    const w = state.wizard;
    if (w.step === 1 && !w.data.name.trim()) {
      toast(t("requiredField") + ": " + t("fullName"), true);
      return;
    }
    if (w.step < TOTAL_STEPS) { w.step++; renderWizard(); return; }
    // final step -> save
    try {
      const payload = Object.assign({}, w.data);
      delete payload.showExtraLabs;
      const method = w.editingId ? "PUT" : "POST";
      const url = w.editingId ? "/api/patients/" + w.editingId : "/api/patients";
      const res = await api(url, { method, body: JSON.stringify(payload) });
      toast(t("saved"));
      openPatient(res.patient.id);
    } catch (e) {
      toast(t("errorGeneric"), true);
    }
  });

  /* ============ education library ============ */
  const EDU_CONTENT = [
    {
      icon: "🩺", titleEn: "What is Peritoneal Dialysis?", titleAr: "ما هو الديلزة البريتونية (PD)؟",
      pointsEn: [
        "PD uses the lining of the abdomen (peritoneum) as a natural filter to remove waste and extra fluid.",
        "A soft catheter is placed in the abdomen; dialysis fluid is exchanged several times a day or overnight with a machine (APD).",
        "Can often be done at home, giving more flexibility than in-center hemodialysis.",
      ],
      pointsAr: [
        "يستخدم PD الغشاء البريتوني في البطن كمرشح طبيعي لإزالة الفضلات والسوائل الزائدة.",
        "توضع قسطرة ناعمة في البطن، ويتم تبديل السائل عدة مرات يومياً أو ليلاً عبر جهاز (APD).",
        "غالباً يمكن إجراؤه في المنزل، مما يمنح مرونة أكبر مقارنة بغسيل الكلى في المركز.",
      ],
    },
    {
      icon: "✅", titleEn: "Who is a Good Candidate?", titleAr: "من هو المرشح المناسب؟",
      pointsEn: [
        "Motivated patient (or caregiver) able to learn a sterile exchange technique.",
        "No major uncontrolled abdominal wall issues (hernia, extensive adhesions/surgery) — evaluate case by case.",
        "Adequate home hygiene and storage space for supplies.",
        "Stable home environment and reasonable manual dexterity / vision, or a trained care giver.",
      ],
      pointsAr: [
        "مريض (أو مرافق) متحمس وقادر على تعلم تقنية التبديل المعقمة.",
        "عدم وجود مشاكل كبيرة غير مسيطر عليها في جدار البطن (فتق، التصاقات واسعة/عمليات سابقة) — يُقيّم كل حالة على حدة.",
        "نظافة منزلية جيدة ومساحة تخزين مناسبة للمستلزمات.",
        "بيئة منزلية مستقرة ومهارة يدوية / رؤية معقولة، أو وجود مرافق مدرَّب.",
      ],
    },
    {
      icon: "🚭", titleEn: "Modifiable Risk Factors to Address", titleAr: "عوامل خطر يمكن تعديلها",
      pointsEn: [
        "Smoking cessation counseling — improves wound/exit-site healing and overall outcomes.",
        "Chronic constipation should be managed before catheter insertion — it can impair drainage and increase leak/migration risk.",
        "Chronic cough should be evaluated — raised intra-abdominal pressure can predispose to leaks and hernia.",
        "Review hygiene practices and home setup to reduce peritonitis risk.",
      ],
      pointsAr: [
        "تقديم إرشاد للإقلاع عن التدخين — يحسن التئام الجرح/موقع الخروج والنتائج العامة.",
        "يجب معالجة الإمساك المزمن قبل تركيب القسطرة — يمكن أن يعيق التصريف ويزيد خطر التسرب أو انزياح القسطرة.",
        "يجب تقييم الكحة المزمنة — ارتفاع الضغط داخل البطن قد يهيئ لحدوث تسرب أو فتق.",
        "مراجعة ممارسات النظافة وترتيب المنزل لتقليل خطر التهاب الصفاق.",
      ],
    },
    {
      icon: "🍽️", titleEn: "Diet & Fluid Guidance", titleAr: "إرشادات الغذاء والسوائل",
      pointsEn: [
        "Individualized protein, potassium, phosphate and fluid targets — refer to a renal dietitian.",
        "Monitor for weight gain / fluid overload versus dehydration; adjust dialysate strength as prescribed.",
        "Encourage a food/fluid diary for the first weeks on PD.",
      ],
      pointsAr: [
        "أهداف فردية للبروتين والبوتاسيوم والفوسفات والسوائل — يُحال المريض لأخصائي تغذية كلوية.",
        "مراقبة زيادة الوزن/احتباس السوائل مقابل الجفاف؛ تعديل تركيز محلول الديلزة حسب الوصف.",
        "تشجيع تدوين مذكرة غذاء/سوائل خلال الأسابيع الأولى من PD.",
      ],
    },
    {
      icon: "🧴", titleEn: "Exit-Site & Infection Prevention", titleAr: "العناية بموقع الخروج والوقاية من العدوى",
      pointsEn: [
        "Daily exit-site care with prescribed antiseptic; keep the site dry and secured.",
        "Teach hand hygiene and sterile connection technique thoroughly before discharge.",
        "Educate on signs of infection: redness, discharge, pain, cloudy dialysate, fever — when to call the clinic immediately.",
      ],
      pointsAr: [
        "عناية يومية بموقع الخروج بالمطهر الموصوف؛ إبقاء المنطقة جافة ومثبتة جيداً.",
        "تعليم نظافة اليدين وتقنية التوصيل المعقمة بدقة قبل الخروج من المستشفى.",
        "توعية المريض بعلامات العدوى: احمرار، إفرازات، ألم، عكارة السائل، حمى — ومتى يتصل بالعيادة فوراً.",
      ],
    },
    {
      icon: "📋", titleEn: "Care Plan Pathways", titleAr: "مسارات خطة الرعاية",
      pointsEn: [
        "Follow-up: continue routine pre-dialysis education and re-assessment.",
        "PD catheter insertion: refer to surgery/interventional team once labs and fitness are confirmed.",
        "Pre-HD clinic: for patients choosing or requiring hemodialysis instead — vascular access planning begins here.",
      ],
      pointsAr: [
        "متابعة: الاستمرار في التثقيف الروتيني لما قبل الديلزة وإعادة التقييم.",
        "تركيب قسطرة PD: يُحال للفريق الجراحي/التداخلي بعد تأكيد نتائج التحاليل والأهلية.",
        "عيادة ما قبل غسيل الدم: للمرضى الذين يختارون أو يحتاجون غسيل الدم بدلاً من ذلك — يبدأ هنا التخطيط للوصول الوعائي.",
      ],
    },
  ];
  const EDU_SOURCES = [
    { name: "National Kidney Foundation (NKF) — kidney.org", url: "https://www.kidney.org" },
    { name: "International Society for Peritoneal Dialysis (ISPD) Guidelines", url: "https://ispd.org" },
    { name: "KDIGO Clinical Practice Guidelines", url: "https://kdigo.org" },
    { name: "NKF CKD-EPI 2021 GFR Calculator (equation source)", url: "https://www.kidney.org/professionals/gfr_calculator" },
  ];

  function renderEducation() {
    $("#edu-title").textContent = t("eduTitle");
    $("#edu-subtitle").textContent = t("eduSubtitle");
    $("#edu-sources-title").textContent = t("eduSources");
    const lang = window.I18N.getLang();
    $("#edu-grid").innerHTML = EDU_CONTENT.map((c) => `
      <div class="edu-card">
        <h3>${c.icon} ${esc(lang === "ar" ? c.titleAr : c.titleEn)}</h3>
        <ul>${(lang === "ar" ? c.pointsAr : c.pointsEn).map((p) => `<li>${esc(p)}</li>`).join("")}</ul>
      </div>
    `).join("");
    $("#edu-sources").innerHTML = EDU_SOURCES.map((s) => `<div>🔗 <a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.name)}</a></div>`).join("");
  }

  /* ============ boot ============ */
  async function bootApp() {
    showApp();
    applyStaticTranslations();
    navigateTo("dashboard");
  }

  async function init() {
    const lang = window.I18N.getLang();
    document.documentElement.lang = lang;
    document.body.dir = lang === "ar" ? "rtl" : "ltr";
    applyStaticTranslations();
    $("#auth-lang-toggle").textContent = t("langToggle");
    $("#btn-lang-toggle").textContent = t("langToggle");

    try {
      const sess = await fetch("/api/session").then((r) => r.json());
      state.needsSetup = sess.needsSetup;
      if (sess.loggedIn) {
        await bootApp();
      } else {
        showAuth();
      }
    } catch (e) {
      showAuth();
    }
  }

  init();
})();
