/**
 * eGFR calculation - CKD-EPI 2021 Creatinine Equation (race-free)
 * Source: Inker LA, et al. N Engl J Med. 2021;385:1737-1749.
 * Endorsed by the National Kidney Foundation / ASN Task Force and used by
 * the NKF's official GFR calculator (kidney.org).
 *
 * eGFR = 142 x min(Scr/kappa, 1)^alpha x max(Scr/kappa, 1)^(-1.200) x 0.9938^Age x (1.012 if female)
 *   kappa = 61.9 (female) / 79.6 (male)   [SI units: umol/L]
 *   alpha = -0.241 (female) / -0.302 (male)
 *   Scr in umol/L (micromol/L) — the SI unit used on most lab reports
 *   outside the US. kappa here is the standard mg/dL kappa (0.7 / 0.9)
 *   converted using 1 mg/dL = 88.4 umol/L.
 *
 * This file is shared verbatim between the Node server and the browser
 * (UMD-style export) so the same calculation runs in both places.
 */
(function (root) {
  "use strict";

  function calcEGFR(creatinineUmolL, ageYears, gender) {
    var scr = Number(creatinineUmolL);
    var age = Number(ageYears);
    var sex = String(gender || "").toLowerCase();

    if (!scr || scr <= 0 || !age || age <= 0) return null;
    if (sex !== "male" && sex !== "female") return null;

    var kappa = sex === "female" ? 61.9 : 79.6;
    var alpha = sex === "female" ? -0.241 : -0.302;
    var sexFactor = sex === "female" ? 1.012 : 1.0;

    var ratio = scr / kappa;
    var minTerm = Math.pow(Math.min(ratio, 1), alpha);
    var maxTerm = Math.pow(Math.max(ratio, 1), -1.2);
    var ageTerm = Math.pow(0.9938, age);

    var egfr = 142 * minTerm * maxTerm * ageTerm * sexFactor;
    return Math.round(egfr * 10) / 10;
  }

  function gfrStage(egfr) {
    if (egfr === null || egfr === undefined || isNaN(egfr)) return null;
    if (egfr >= 90) return { code: "G1", labelEn: "Normal / High", labelAr: "طبيعي", status: "good" };
    if (egfr >= 60) return { code: "G2", labelEn: "Mildly decreased", labelAr: "انخفاض بسيط", status: "good" };
    if (egfr >= 45) return { code: "G3a", labelEn: "Mild-moderate decrease", labelAr: "انخفاض بسيط الى متوسط", status: "warning" };
    if (egfr >= 30) return { code: "G3b", labelEn: "Moderate-severe decrease", labelAr: "انخفاض متوسط الى شديد", status: "warning" };
    if (egfr >= 15) return { code: "G4", labelEn: "Severely decreased", labelAr: "انخفاض شديد", status: "serious" };
    return { code: "G5", labelEn: "Kidney failure", labelAr: "فشل كلوي", status: "critical" };
  }

  var api = { calcEGFR: calcEGFR, gfrStage: gfrStage };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  } else {
    root.GFR = api;
  }
})(typeof window !== "undefined" ? window : this);
