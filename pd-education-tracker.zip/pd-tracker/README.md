# PD Education Tracker / متابعة تثقيف مرضى ما قبل الديلزة

A bilingual (English / Arabic) clinic dashboard for tracking **pre-dialysis
patient education** sessions: patient demographics & vitals, dialysis history
and vascular access, labs with automatic eGFR calculation, comorbidities
(diabetes, hypertension, cardiac, respiratory), PD (peritoneal dialysis)
suitability criteria, hernia/bowel/hygiene/fluid assessment, medications,
surgeon & nephrologist sign-off, fitness decision, and follow-up plan —
sortable by urea so you can see who needs attention first. The intake form
mirrors a standard hospital Pre-Peritoneal-Dialysis Assessment form.

All patient data is stored in a local file (`data/db.json`) on whichever
computer/server runs the app. Nothing is sent to any third party.

---

## 0. Getting a permanent public link (so it opens from anywhere)

Running it on your own computer (section 1 below) only makes it reachable
from that computer. To get a permanent web link you can open from any
device, the app needs to run on a small always-on server. Two easy, mostly-free
options:

**Option A — Render.com (recommended, has a free tier)**
1. Create a free account at https://render.com
2. Create a new **Web Service**, and point it at this project's code (upload
   it to a GitHub repo first, or ask a technical colleague to help — Render
   deploys straight from a GitHub repo).
3. Build command: `npm install` — Start command: `npm start`
4. Add an environment variable `SESSION_SECRET` with any random long text.
5. Deploy. Render gives you a permanent `https://your-app.onrender.com` link.

**Option B — Railway.app** works the same way, with a similarly simple
free-tier deploy flow at https://railway.app.

If you're chatting with Claude about this project and connect your Render
or Railway account (Settings → Connectors, in the Claude app), Claude can
create and deploy the web service for you directly and hand you back the
live link — just ask.

---

## 1. English — how to run it

### Requirements
- [Node.js](https://nodejs.org) version 16 or newer (includes `npm`).
  To check if you already have it, open a terminal and run `node -v`.

### First-time setup
1. Unzip this project folder anywhere on your computer.
2. Open a terminal in that folder.
3. Install dependencies (one-time):
   ```
   npm install
   ```
4. Start the app:
   ```
   npm start
   ```
5. Open your browser at **http://localhost:3000**
6. The first time you open it, you'll be asked to create a password —
   this protects your patients' data. Remember it; there is no "forgot
   password" flow, but you (or a technical colleague) can reset it by
   deleting the `data/db.json` file, which also erases all patient records,
   so only do this if you're sure.

### Using it every day
- Just run `npm start` in the project folder and open
  http://localhost:3000 again — your data is still there.
- To keep it running in the background, or to make it reachable from other
  computers/tablets on your clinic network or the internet, ask a
  technical colleague to help you deploy it to a small server (for
  example, using a service like Render, Railway, or a VPS) and to put it
  behind HTTPS. The app itself doesn't need any changes for that — it's a
  standard Node.js web app.

### Backing up your data
All patient records live in a single file: `data/db.json`. Copy this file
somewhere safe periodically (e.g. a backup drive) to avoid losing data.

### Changing your password
Once logged in, click **Settings** in the top-right corner.

### The eGFR formula used
eGFR is calculated automatically from creatinine, age and gender using the
**CKD-EPI 2021 creatinine equation (race-free)** — the equation currently
endorsed by the National Kidney Foundation / American Society of
Nephrology Task Force and used in the NKF's own official GFR calculator
(kidney.org). The formula lives in `public/js/gfr.js` if you ever want to
review or audit it.

---

## 2. العربية — طريقة التشغيل

### الحصول على رابط دائم على الإنترنت
تشغيل الموقع على جهازك (القسم التالي) يخليه يفتح من هذا الجهاز فقط. عشان
تحصل على رابط دائم يفتح من أي مكان، الموقع لازم يشتغل على سيرفر صغير شغال
طول الوقت. أسهل خيارين (فيهم باقة مجانية):

- **Render.com** (موصى به): أنشئ حساب مجاني، اعمل "Web Service" جديد واربطه
  بمستودع GitHub فيه كود المشروع (ارفع الكود لمستودع GitHub أولاً، أو استعن
  بزميل تقني). أوامر التشغيل: Build = `npm install`، Start = `npm start`.
  بعد النشر بتاخذ رابط دائم مثل `https://your-app.onrender.com`.
- **Railway.app**: نفس الفكرة، بخطوات بسيطة مشابهة.

إذا كنت تحكي مع Claude عن هذا المشروع وربطت حساب Render أو Railway (من
إعدادات الاتصالات Connectors)، يقدر Claude ينشر الموقع لك مباشرة ويعطيك
الرابط الجاهز — فقط اطلب ذلك.

### المتطلبات
- تحتاج إلى تثبيت [Node.js](https://nodejs.org) (الإصدار 16 أو أحدث). للتأكد
  إن كان مثبتاً لديك، افتح الطرفية (Terminal) واكتب: `node -v`

### الإعداد لأول مرة
1. فك ضغط مجلد المشروع في أي مكان على جهازك.
2. افتح الطرفية (Terminal) داخل هذا المجلد.
3. ثبّت المكتبات المطلوبة (مرة واحدة فقط):
   ```
   npm install
   ```
4. شغّل الموقع:
   ```
   npm start
   ```
5. افتح المتصفح على العنوان: **http://localhost:3000**
6. أول مرة تفتح الموقع، سيُطلب منك إنشاء كلمة مرور لحماية بيانات مرضاك.
   احفظها جيداً — لا يوجد خيار "نسيت كلمة المرور"، لكن يمكنك (أو زميل تقني)
   إعادة التعيين بحذف الملف `data/db.json`، مع العلم أن هذا سيحذف جميع بيانات
   المرضى أيضاً، فقم بذلك فقط إن كنت متأكداً.

### الاستخدام اليومي
- فقط شغّل الأمر `npm start` داخل مجلد المشروع وافتح
  http://localhost:3000 من جديد — بياناتك محفوظة كما هي.
- إذا أردت إبقاء الموقع يعمل بشكل دائم، أو جعله متاحاً من أجهزة/تابلت أخرى
  في العيادة أو عبر الإنترنت، يمكن لزميل تقني مساعدتك في نشره على خادم
  بسيط (مثل Render أو Railway أو أي VPS) مع تفعيل HTTPS. لا حاجة لأي تعديل
  على الكود لذلك.

### النسخ الاحتياطي للبيانات
جميع بيانات المرضى محفوظة في ملف واحد: `data/db.json`. من المستحسن نسخ هذا
الملف بشكل دوري لمكان آمن لتفادي فقدان البيانات.

### تغيير كلمة المرور
بعد تسجيل الدخول، اضغط على **الإعدادات** أعلى يمين الصفحة.

### معادلة حساب GFR المستخدمة
يُحسب GFR تلقائياً من الكرياتينين والعمر والجنس باستخدام معادلة
**CKD-EPI 2021** (النسخة المستقلة عن العرق) — وهي المعادلة المعتمدة حالياً
من National Kidney Foundation / ASN Task Force، والمستخدمة في حاسبة GFR
الرسمية على موقعهم (kidney.org). يمكنك مراجعة المعادلة في الملف
`public/js/gfr.js`.

---

## Project structure
```
pd-tracker/
  server.js          Express server + API routes + auth
  lib/db.js           Simple JSON-file data layer (no external database needed)
  public/
    index.html         App shell (login + dashboard + wizard + education library)
    css/style.css       Styling
    js/gfr.js            eGFR calculation (CKD-EPI 2021)
    js/i18n.js            English/Arabic translations
    js/app.js              Frontend logic
  data/db.json         Created automatically — your patient data lives here
```

## Notes for a technical colleague
- No native/compiled dependencies (pure JS + `express`, `express-session`,
  `bcryptjs`), so `npm install` works anywhere without a build toolchain.
- Single-user password auth via `express-session` + `bcryptjs`, stored in
  `data/db.json`. Fine for a single clinician; if this needs multi-user
  accounts, roles, or a real database (Postgres/MySQL) for higher
  concurrency, that's a straightforward extension of `lib/db.js` and the
  `/api/*` routes in `server.js`.
- Set `PORT` and `SESSION_SECRET` environment variables to customize the
  port and session secret in production.
